import paho.mqtt.client as mqtt

print("Starting Publisher")

topic = "diot"
QoS =0

client = mqtt.Client()


client.connect("127.0.0.1",1883)
	
client.loop_start()

try:
	while True:
		message = input("Enter message to change : ")
		(rc,mid) = client.publish(topic,message.Qos)
		if rc==0:
			print("--Message Sent--")
except KeyboardInterrupt:
	client.disconnect()
	client.loop_stop()